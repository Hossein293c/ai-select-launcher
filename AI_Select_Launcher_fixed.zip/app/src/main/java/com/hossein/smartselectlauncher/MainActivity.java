package com.hossein.smartselectlauncher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    private static final String TARGET_PACKAGE =
            "com.samsung.android.app.smartcapture";
    private static final String TARGET_ACTIVITY =
            "com.samsung.android.app.smartcapture.aiassist.controller.AiAssistSmartSelectActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.setComponent(new ComponentName(TARGET_PACKAGE, TARGET_ACTIVITY));
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) {
            // If Samsung Capture is unavailable or the activity is blocked,
            // simply close the launcher.
        }

        finish();
    }
}
