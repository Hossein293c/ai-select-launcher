AI Select Launcher

Purpose:
A tiny launcher app whose only job is to open Samsung Capture's real
Smart Select activity.

Target package:
com.samsung.android.app.smartcapture

Target activity:
com.samsung.android.app.smartcapture.aiassist.controller.AiAssistSmartSelectActivity

The Activity is intentionally exported as the normal launcher entry point.
The launcher immediately starts the Samsung activity and then finishes.

Build:
Open this folder in Android Studio and build the debug APK.
The resulting APK will be in:
app/build/outputs/apk/debug/app-debug.apk

The icon is intentionally left as the default placeholder for now so it
can be replaced later with the user's preferred Smart Select icon.
